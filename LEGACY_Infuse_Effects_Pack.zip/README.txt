LEGACY SMP — Infuse SMP 2.4.3 effect icons

This pack maps the exact private-use Unicode glyphs used by InfuseSMP 2.4.3's ActionBarUpdater:
- Regular icons: U+E001 through U+E00F
- Active icons: U+E101 through U+E10F
- Augmented icons: U+E201 through U+E20F
- Augmented active icons: U+E301 through U+E30F

The plugin displays the two equipped effect slots in the action bar above the hotbar. These font glyphs make those characters render as custom pictures.

IMPORTANT:
- The pack is a custom-made interpretation of the effects, not the original Infuse SMP artwork.
- This pack overrides assets/minecraft/font/default.json to register the glyphs. If another resource pack already overrides that file, merge the provider into that pack's default.json rather than enabling conflicting packs.
- Test with your exact Minecraft Java client version. Resource-pack pack_format values vary by client version; if 1.21.11 warns that the pack is incompatible, update pack.mcmeta to the correct format for your client.
- If you use the server resource-pack feature, host this ZIP at a direct HTTPS download URL and configure resource-pack in server.properties.
